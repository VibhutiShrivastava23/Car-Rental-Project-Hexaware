export class Payment {
    public payId : number;
    public userId :number ;
    public resId : number;
    public amount : number;
    public paymentMethod : string;
    public status : string;
    public paymentPurpose : string;
    public payDate : Date;
    
    constructor() {}
}
