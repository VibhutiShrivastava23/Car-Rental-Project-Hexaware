export class Refund {
    public refundId : number;
    public userId :number ;
    public payId : number;
    public refundAmount : number;
    public refundDate : Date;
    public refundMethod : string;
    public refundStatus : string;

    
    constructor() {}
}
