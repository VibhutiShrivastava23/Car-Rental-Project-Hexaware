export class Admin {
    public adminId : number;
    public email : string;
    public password : string;
    
    constructor() {}
}
