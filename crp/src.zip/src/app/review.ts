export class Review {
    public revId : number;
    public userId :number ;
    public rating : number;
    public review : string;
    
    constructor() {}
}
