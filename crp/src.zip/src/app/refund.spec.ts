import { Refund } from './refund';

describe('Refund', () => {
  it('should create an instance', () => {
    expect(new Refund()).toBeTruthy();
  });
});
