export class Car {
    public carid : number;
    public make : string;
    public model : string;
    public year : number;
    public location : string;
    public fastag : string;
    public price : number;
    public availability : string;
    public category : string;
    public fuelType : string;
    public gearType : string;
    public action:string;
    [key: string]: any; 
    constructor() {}
}
