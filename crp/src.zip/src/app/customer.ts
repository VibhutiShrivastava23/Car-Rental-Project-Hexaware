export class Customer {
    public userId : number;
    public firstname : string;
    public lastname : string;
    public city : number;
    public state : string;
    public address : string;
    public phoneno : number;
    public email : string;
    public status : string;

    
    constructor() {}
}


